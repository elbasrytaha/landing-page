import React from 'react';
import { AwardIcon } from './Icons';
import { ContentStructure } from '../types';

interface CertificationsProps {
  content: ContentStructure['certifications'];
}

const Certifications: React.FC<CertificationsProps> = ({ content }) => {
  return (
    <section className="py-16 px-6 bg-slate-900 border-t border-slate-800">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 flex items-center justify-center gap-4">
          <AwardIcon className="w-8 h-8 md:w-10 md:h-10 text-orange-500" />
          {content.title}
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {content.items.map((item, index) => (
            <div 
              key={index}
              className="bg-slate-800 p-6 rounded-2xl border border-slate-700 hover:border-orange-500/50 transition-colors group"
            >
              <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-500/20 transition-colors">
                <AwardIcon className="w-8 h-8 text-slate-400 group-hover:text-orange-500 transition-colors" />
              </div>
              <p className="text-lg font-medium text-slate-200">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;