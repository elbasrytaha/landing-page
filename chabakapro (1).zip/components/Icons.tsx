import React from 'react';
import { Phone, Wifi, Camera, CheckCircle2, ShieldCheck, Globe, Facebook, Instagram, Linkedin, Award, X, User, Mail, MapPin, Send } from 'lucide-react';

export const PhoneIcon = ({ className }: { className?: string }) => <Phone className={className} />;
export const WifiIcon = ({ className }: { className?: string }) => <Wifi className={className} />;
export const CameraIcon = ({ className }: { className?: string }) => <Camera className={className} />;
export const CheckIcon = ({ className }: { className?: string }) => <CheckCircle2 className={className} />;
export const ShieldIcon = ({ className }: { className?: string }) => <ShieldCheck className={className} />;
export const GlobeIcon = ({ className }: { className?: string }) => <Globe className={className} />;
export const FacebookIcon = ({ className }: { className?: string }) => <Facebook className={className} />;
export const InstagramIcon = ({ className }: { className?: string }) => <Instagram className={className} />;
export const LinkedinIcon = ({ className }: { className?: string }) => <Linkedin className={className} />;
export const AwardIcon = ({ className }: { className?: string }) => <Award className={className} />;
export const CloseIcon = ({ className }: { className?: string }) => <X className={className} />;
export const UserIcon = ({ className }: { className?: string }) => <User className={className} />;
export const MailIcon = ({ className }: { className?: string }) => <Mail className={className} />;
export const MapPinIcon = ({ className }: { className?: string }) => <MapPin className={className} />;
export const SendIcon = ({ className }: { className?: string }) => <Send className={className} />;