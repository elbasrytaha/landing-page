import React, { useState } from 'react';
import { LeadFormContent } from '../types';
import { UserIcon, MailIcon, PhoneIcon, MapPinIcon, SendIcon, CheckIcon } from './Icons';

interface LeadFormProps {
  content: LeadFormContent;
  lang: string;
}

const LeadForm: React.FC<LeadFormProps> = ({ content, lang }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: 'Casablanca' // Default choice
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      console.log('Form Submitted:', formData);
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  return (
    <section className="relative px-6 z-20 -mt-24 md:-mt-32 mb-12">
      <div className="max-w-4xl mx-auto">
        <div 
          className="bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden"
          dir={lang === 'ar' ? 'rtl' : 'ltr'}
        >
          {/* Top colored accent line */}
          <div className="h-2 w-full bg-gradient-to-r from-orange-400 to-orange-600"></div>

          <div className="p-8 md:p-12">
            {isSuccess ? (
              <div className="py-12 flex flex-col items-center text-center animate-fade-in-up">
                <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <CheckIcon className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="text-3xl font-bold text-slate-900 mb-4">{content.success.title}</h3>
                <p className="text-xl text-slate-600 max-w-md">{content.success.message}</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-10">
                  <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                    {content.title}
                  </h2>
                  <p className="text-lg md:text-xl text-slate-500 max-w-2xl mx-auto">
                    {content.subtitle}
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Name */}
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 block">{content.labels.name}</label>
                      <div className="relative group">
                        <div className="absolute top-1/2 -translate-y-1/2 ltr:left-4 rtl:right-4 text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <UserIcon className="w-5 h-5" />
                        </div>
                        <input 
                          type="text" 
                          required
                          placeholder={content.placeholders.name}
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-lg rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 block w-full ltr:pl-12 rtl:pr-12 p-4 outline-none transition-all"
                        />
                      </div>
                    </div>

                    {/* Phone */}
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 block">{content.labels.phone}</label>
                      <div className="relative group">
                        <div className="absolute top-1/2 -translate-y-1/2 ltr:left-4 rtl:right-4 text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <PhoneIcon className="w-5 h-5" />
                        </div>
                        <input 
                          type="tel" 
                          required
                          placeholder={content.placeholders.phone}
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-lg rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 block w-full ltr:pl-12 rtl:pr-12 p-4 outline-none transition-all"
                        />
                      </div>
                    </div>

                    {/* Email */}
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-700 block">{content.labels.email}</label>
                      <div className="relative group">
                        <div className="absolute top-1/2 -translate-y-1/2 ltr:left-4 rtl:right-4 text-slate-400 group-focus-within:text-orange-500 transition-colors">
                          <MailIcon className="w-5 h-5" />
                        </div>
                        <input 
                          type="email" 
                          required
                          placeholder={content.placeholders.email}
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-lg rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 block w-full ltr:pl-12 rtl:pr-12 p-4 outline-none transition-all"
                        />
                      </div>
                    </div>

                    {/* City */}
                    <div className="space-y-2">
                       <label className="text-sm font-bold text-slate-700 block">{content.labels.city}</label>
                       <div className="relative group">
                         <div className="absolute top-1/2 -translate-y-1/2 ltr:left-4 rtl:right-4 text-slate-400 group-focus-within:text-orange-500 transition-colors">
                            <MapPinIcon className="w-5 h-5" />
                         </div>
                         <select
                            value={formData.city}
                            onChange={(e) => setFormData({...formData, city: e.target.value})}
                            className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-lg rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 block w-full ltr:pl-12 rtl:pr-12 p-4 outline-none transition-all appearance-none cursor-pointer"
                         >
                           <option value="Casablanca">{content.options.casablanca}</option>
                           <option value="Other">{content.options.other}</option>
                         </select>
                         <div className="absolute top-1/2 -translate-y-1/2 ltr:right-4 rtl:left-4 text-slate-400 pointer-events-none">
                            <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                         </div>
                       </div>
                    </div>
                  </div>

                  {/* Address */}
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700 block">{content.labels.address}</label>
                    <textarea 
                      rows={2}
                      placeholder={content.placeholders.address}
                      value={formData.address}
                      onChange={(e) => setFormData({...formData, address: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 text-lg rounded-xl focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 block w-full p-4 outline-none transition-all resize-none"
                    ></textarea>
                  </div>

                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white text-xl font-bold py-5 rounded-xl shadow-lg shadow-orange-200 transform transition-all hover:-translate-y-1 hover:shadow-xl active:translate-y-0 active:scale-[0.99] flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
                  >
                    {isSubmitting ? (
                      <span>{content.submitting}</span>
                    ) : (
                      <>
                        <span>{content.submit}</span>
                        <SendIcon className={`w-6 h-6 ${lang === 'ar' ? 'rotate-180' : ''}`} />
                      </>
                    )}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LeadForm;