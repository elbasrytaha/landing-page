export type Language = 'ar' | 'fr';

export interface ButtonContent {
  text: string;
  action?: string;
}

export interface OfferContent {
  name: string;
  price: string;
  features: string[];
  button: string;
  isPopular?: boolean;
}

export interface LeadFormContent {
  title: string;
  subtitle: string;
  labels: {
    name: string;
    email: string;
    phone: string;
    city: string;
    address: string;
  };
  placeholders: {
    name: string;
    email: string;
    phone: string;
    address: string;
  };
  options: {
    casablanca: string;
    other: string;
  };
  submit: string;
  submitting: string;
  success: {
    title: string;
    message: string;
  };
}

export interface ContentStructure {
  labels: {
    recommended: string;
  };
  header: {
    title: string;
    subtitle: string;
    button: ButtonContent;
  };
  body: {
    description: string;
    offers: OfferContent[];
  };
  certifications: {
    title: string;
    items: string[];
  };
  leadForm: LeadFormContent;
  footer: {
    text: string;
    trustMessage: string;
    contact: {
      phone: string;
      whatsapp: boolean;
    };
    social: {
      facebook: string;
      instagram: string;
      linkedin: string;
    };
  };
}

export interface AppContent {
  ar: ContentStructure;
  fr: ContentStructure;
}